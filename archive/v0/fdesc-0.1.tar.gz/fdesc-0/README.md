# fdesc program
C command line application generarte fake description.

# build                 
```sh                
$ make fdesc
```

# clean
```sh                
$ make clean
```
